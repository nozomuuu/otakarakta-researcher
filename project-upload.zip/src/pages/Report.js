import { useState, useEffect, useRef } from "react"
import { useNavigate, useLocation } from "react-router-dom"
import { photoStorage } from "../utils/photoStorage"
import "./Report.css"

const Report = () => {
  const [photos, setPhotos] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)
  const [selectedIndex, setSelectedIndex] = useState(0)
  const [bestShotIndex, setBestShotIndex] = useState(null)
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const [isTransitioning, setIsTransitioning] = useState(true)
  const navigate = useNavigate()
  const location = useLocation()
  const mounted = useRef(true)

  // Initialize component with transition
  useEffect(() => {
    const loadPhotos = async () => {
      try {
        // Add delay if coming from TakePhoto
        if (location.state?.fromTakePhoto) {
          await new Promise((resolve) => setTimeout(resolve, 1000))
        }

        const savedPhotos = photoStorage.load()
        console.log("Loaded photos:", savedPhotos)

        if (!savedPhotos || savedPhotos.length === 0) {
          throw new Error("写真が見つかりません")
        }

        if (mounted.current) {
          setPhotos(savedPhotos)
          setError(null)
          // Delay showing content for smooth transition
          setTimeout(() => {
            if (mounted.current) {
              setIsTransitioning(false)
            }
          }, 100)
        }
      } catch (err) {
        console.error("Error loading photos:", err)
        if (mounted.current) {
          setError(err.message)
          setIsTransitioning(false)
        }
      } finally {
        if (mounted.current) {
          setIsLoading(false)
        }
      }
    }

    loadPhotos()

    return () => {
      mounted.current = false
    }
  }, [location.state])

  const handleThumbnailClick = (index) => {
    new Audio("/button.mp3").play().catch(console.error)
    setSelectedIndex(index)
  }

  const handleSetBestShot = () => {
    new Audio("/button.mp3").play().catch(console.error)
    setBestShotIndex(selectedIndex)
  }

  const handleFinishReport = () => {
    new Audio("/button.mp3").play().catch(console.error)
    setShowConfirmDialog(true)
  }

  const handleReturnHome = () => {
    new Audio("/button.mp3").play().catch(console.error)
    photoStorage.clear()
    navigate("/")
  }

  // Render loading state
  if (isLoading) {
    return (
      <div className="report-container">
        <div className="game-window">
          <div className="screen-container">
            <div className="message-box">よみこんでいます...</div>
          </div>
        </div>
      </div>
    )
  }

  // Render error state
  if (error) {
    return (
      <div className="report-container">
        <div className="game-window">
          <div className="screen-container">
            <div className="message-box">
              エラーが発生しました。
              <br />
              もういちどさつえいしてください。
              <br />
              <small>{error}</small>
            </div>
            <button className="action-button" onClick={() => navigate("/takephoto")}>
              さつえいにもどる
            </button>
          </div>
        </div>
      </div>
    )
  }

  // Main render
  return (
    <div className={`report-container ${isTransitioning ? "transitioning" : "show"}`}>
      <div className="game-window">
        <div className="screen-container">
          <div className="content-area">
            <div className="message-box">
              おつかれさまでした。けっかをほうこくしましょう。
              <br />
              とったしゃしんのなかからベストショットを１まいえらんでください
            </div>

            <div className="photo-display-area">
              <img src={photos[selectedIndex]?.data || "/placeholder.svg"} alt="選択中の写真" className="main-photo" />
            </div>

            <div className="controls-area">
              <div className="thumbnails-area">
                <button
                  className="nav-button"
                  onClick={() => setSelectedIndex((prev) => Math.max(0, prev - 1))}
                  disabled={selectedIndex === 0}
                >
                  ＜
                </button>
                <div className="thumbnails-scroll">
                  <div className="thumbnails-track">
                    {photos.map((photo, index) => (
                      <div
                        key={photo.id}
                        className={`thumbnail-wrapper ${index === selectedIndex ? "selected" : ""} ${
                          index === bestShotIndex ? "best-shot" : ""
                        }`}
                        onClick={() => handleThumbnailClick(index)}
                      >
                        <img src={photo.data || "/placeholder.svg"} alt={`写真 ${index + 1}`} className="thumbnail" />
                        <div className="thumbnail-number">{index + 1}</div>
                        {index === bestShotIndex && <div className="star-mark">★</div>}
                      </div>
                    ))}
                  </div>
                </div>
                <button
                  className="nav-button"
                  onClick={() => setSelectedIndex((prev) => Math.min(photos.length - 1, prev + 1))}
                  disabled={selectedIndex === photos.length - 1}
                >
                  ＞
                </button>
              </div>

              <div className="button-container">
                <button className="action-button" onClick={handleSetBestShot}>
                  ベストショットにする
                </button>
                <button className="action-button" onClick={handleFinishReport} disabled={bestShotIndex === null}>
                  ほうこくをおわる
                </button>
              </div>
            </div>
          </div>

          {showConfirmDialog && (
            <div className="confirm-dialog">
              <div className="confirm-content">
                <p>このしゃしんでほうこくしますか？</p>
                <div className="confirm-buttons">
                  <button onClick={handleReturnHome}>はい</button>
                  <button onClick={() => setShowConfirmDialog(false)}>いいえ</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Report

