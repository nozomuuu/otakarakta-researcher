// Utility for managing photos in localStorage
export const photoStorage = {
  STORAGE_KEY: "otakarakuta_photos",

  save: (photos) => {
    try {
      if (!Array.isArray(photos)) {
        console.error("Invalid photos data:", photos)
        return false
      }
      const serializedPhotos = JSON.stringify(photos)
      localStorage.setItem(photoStorage.STORAGE_KEY, serializedPhotos)
      console.log("Photos saved successfully:", photos.length)
      return true
    } catch (error) {
      console.error("Failed to save photos:", error)
      return false
    }
  },

  load: () => {
    try {
      const data = localStorage.getItem(photoStorage.STORAGE_KEY)
      if (!data) {
        console.log("No photos found in storage")
        return []
      }
      const photos = JSON.parse(data)
      if (!Array.isArray(photos)) {
        console.error("Invalid photos data in storage")
        return []
      }
      console.log("Photos loaded successfully:", photos.length)
      return photos
    } catch (error) {
      console.error("Failed to load photos:", error)
      return []
    }
  },

  clear: () => {
    try {
      localStorage.removeItem(photoStorage.STORAGE_KEY)
      console.log("Photos cleared successfully")
      return true
    } catch (error) {
      console.error("Failed to clear photos:", error)
      return false
    }
  },

  // Add a new method to verify storage
  verify: () => {
    try {
      const testKey = `${photoStorage.STORAGE_KEY}_test`
      localStorage.setItem(testKey, "test")
      localStorage.removeItem(testKey)
      return true
    } catch (error) {
      console.error("Storage not available:", error)
      return false
    }
  },
}

